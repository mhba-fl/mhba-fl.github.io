import Image from "next/image"
import { CalendarDays, Clock, MapPin } from "lucide-react"
import { Card } from "@/components/ui/card"

export default function HealthcareForum() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Hero Section */}
      <section className="relative h-[500px] overflow-hidden">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-QqSP0qrjB48K0F9AeYRJbxe26B3O1L.png"
          alt="SIT Campus"
          className="object-cover"
          fill
          priority
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="container relative z-10 mx-auto px-4 py-20">
          <div className="max-w-3xl text-white">
            <h1 className="mb-6 text-4xl font-bold leading-tight md:text-5xl">SITxUoG AI-Healthcare Forum</h1>
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <CalendarDays className="h-5 w-5" />
                <span>February 7, 2025</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                <span>2-6 PM</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                <span>Room SR343, Level 3, Building E6 at SIT Punggol Campus</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Program Schedule */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="mb-12 text-center text-3xl font-bold">Program Schedule</h2>
          <div className="mx-auto max-w-3xl space-y-4">
            {scheduleItems.map((item, index) => (
              <div
                key={index}
                className="flex flex-col gap-4 rounded-lg border bg-white p-4 shadow-sm transition-all hover:shadow-md sm:flex-row sm:items-center"
              >
                <div className="min-w-[140px] rounded-md bg-primary/10 px-3 py-2 text-center font-medium text-primary">
                  {item.time}
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{item.title}</h3>
                  {item.subtitle && <p className="text-sm text-gray-500">{item.subtitle}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Speakers Section */}
      <section className="bg-slate-50 py-20">
        <div className="container mx-auto px-4">
          <h2 className="mb-12 text-center text-3xl font-bold">Keynote Speaker</h2>
          <div className="mx-auto max-w-4xl">
            <SpeakerCard
              name="Dr. Fani Deligianni"
              image="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-MrfnW7aG5I8UOeDQgAR9Sw9Cvoh1nP.png"
              role="Senior Lecturer, School of Computing Science, University of Glasgow"
              presentation="Advancing Medical Computer Vision Through Teacher-Student Learning and Privacy-Preserved Deep Learning Models"
              bio="Dr. Fani Deligianni is a senior lecturer at the School of Computing Science at the University of Glasgow and she has a strong interest in machine learning and computer vision for healthcare applications..."
              bgColor="bg-cyan-400"
            />
          </div>
        </div>
      </section>

      {/* Invited Speakers Grid */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="mb-12 text-center text-3xl font-bold">Invited Speakers</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {speakers.map((speaker, index) => (
              <SpeakerCard key={index} {...speaker} />
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-slate-50 py-20">
        <div className="container mx-auto px-4">
          <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-3">
            <FeatureCard
              image="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-wpKXX20XpTQwN7rLm2Q0ksHa1C7G3Q.png"
              title="Collaborative Networking"
              description="Connect with thought leaders, innovators, and peers from academia and industry to discuss emerging trends, exchange best practices, and identify potential research or project collaborations."
            />
            <FeatureCard
              image="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-wpKXX20XpTQwN7rLm2Q0ksHa1C7G3Q.png"
              title="Interactive Sessions"
              description="Engage in dynamic discussions and presentations led by guest speakers from academia and the healthcare industry. These experts will share insights into privacy-preserving data techniques, AI-driven healthcare advancements, and strategies for safeguarding patient information."
            />
            <FeatureCard
              image="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-wpKXX20XpTQwN7rLm2Q0ksHa1C7G3Q.png"
              title="Poster Showcase"
              description="Explore a captivating poster exhibition featuring innovative projects developed by students. These projects showcase creative solutions and research aligned with the forum's theme of privacy-preserving AI in healthcare, offering a glimpse into the future of the field."
            />
          </div>
        </div>
      </section>
    </div>
  )
}

function SpeakerCard({
  name,
  image,
  role,
  presentation,
  bio,
  bgColor = "bg-white",
}: {
  name: string
  image: string
  role: string
  presentation: string
  bio: string
  bgColor?: string
}) {
  return (
    <Card className={`overflow-hidden ${bgColor}`}>
      <div className="flex flex-col md:flex-row">
        <div className="relative h-64 w-full md:h-auto md:w-1/3">
          <Image src={image || "/placeholder.svg"} alt={name} fill className="object-cover" />
        </div>
        <div className="flex-1 p-6 text-white">
          <h3 className="mb-2 text-xl font-bold">{name}</h3>
          <p className="mb-4 text-sm opacity-90">{role}</p>
          <h4 className="mb-2 font-semibold">Featured Presentation:</h4>
          <p className="mb-4 text-sm opacity-90">{presentation}</p>
          <div className="prose prose-sm prose-invert">
            <h4 className="font-semibold">Biography:</h4>
            <p className="line-clamp-4 text-sm opacity-90">{bio}</p>
          </div>
        </div>
      </div>
    </Card>
  )
}

function FeatureCard({ image, title, description }: { image: string; title: string; description: string }) {
  return (
    <div className="group rounded-lg bg-white p-6 shadow-sm transition-all hover:shadow-md">
      <div className="relative mb-6 h-48 overflow-hidden rounded-lg">
        <Image
          src={image || "/placeholder.svg"}
          alt={title}
          fill
          className="object-cover transition-transform group-hover:scale-105"
        />
      </div>
      <h3 className="mb-3 text-xl font-semibold">{title}</h3>
      <p className="text-sm text-gray-600">{description}</p>
    </div>
  )
}

const scheduleItems = [
  {
    time: "2:00PM - 2:15PM",
    title: "Opening Speech by Prof Vinnod (ICT Cluster Director)",
  },
  {
    time: "2:15PM - 3:15PM",
    title: "Invited Talks",
    subtitle: "20 minutes each",
  },
  {
    time: "3:15PM - 3:50PM",
    title: "Coffee Break + Students Sharing",
  },
  {
    time: "3:50PM - 4:20PM",
    title: "Keynote Talk",
  },
  {
    time: "4:20PM - 5:40PM",
    title: "Invited Talks",
    subtitle: "20 minutes each",
  },
  {
    time: "5:40PM - 5:45PM",
    title: "Closing Remark",
  },
  {
    time: "5:45PM - 6:45PM",
    title: "Dinner and Networking",
  },
]

const speakers = [
  {
    name: "Dr. Chan Yew Weng",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-SRIcFvV2FgXH2s7AMUSOto1lusqe69.png",
    role: "Clinical Associate Professor, Yong Loo Lin School of Medicine",
    presentation: "AI in Healthcare: Best Artificial Intelligence Hospital in the World",
    bio: "Dr. Chan Yew Weng is a distinguished Clinical Associate Professor at the Yong Loo Lin School of Medicine...",
    bgColor: "bg-amber-400",
  },
  {
    name: "Dr. Tim Xu Tianma",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-mT2UbriekUeAC9Jh4eCpa6RDVehaNy.png",
    role: "Associate Professor, Singapore Institute of Technology",
    presentation: "Frailty Management in Singapore: From Research to Real-World Implementation",
    bio: "Dr Tim Xu is an esteemed Occupational Therapy Associate Professor at the Singapore Institute of Technology...",
    bgColor: "bg-violet-500",
  },
  {
    name: "Dr. Abel Zhou",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-a9dS10eDJp8bQbLsoVI5xYNonAhOiF.png",
    role: "Radiography and Medical Imaging Expert",
    presentation: "AI applications in healthcare and diagnostic imaging",
    bio: "Dr. Abel Zhou is a seasoned expert with over 8 years of experience in radiography and medical imaging applications...",
    bgColor: "bg-cyan-400",
  },
]

