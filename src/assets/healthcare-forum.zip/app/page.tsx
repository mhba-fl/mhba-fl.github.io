"use client"

import HealthcareForum from "../page"

export default function SyntheticV0PageForDeployment() {
  return <HealthcareForum />
}